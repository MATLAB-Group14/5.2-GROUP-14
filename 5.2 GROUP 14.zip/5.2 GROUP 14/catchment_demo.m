function catchment_demo()
    % MATLAB implementation for hydrological catchment delineation and runoff simulation
    % Generates synthetic DEM, computes flow direction, accumulation, delineates watershed,
    % calculates runoff using SCS CN method, and estimates peak discharge using Rational method.

    % Create synthetic DEM
    n = 200; [X,Y] = meshgrid(1:n,1:n);
    DEM = 200 + 50*exp(-((X-80).^2+(Y-120).^2)/2000) - 0.2*(X+Y) + 5*randn(n);

    % Fill sinks to remove depressions
    DEM_filled = fill_sinks(DEM);

    % Compute flow direction (D8) and flow accumulation
    fd = flowdir_d8(DEM_filled);
    fa = flowacc_d8(fd);

    % Select pour point (highest accumulation)
    [~, idx] = max(fa(:));
    [py, px] = ind2sub(size(fa), idx);
    pour_point = [px, py];

    % Delineate watershed from pour point
    mask = delineate_from_pour(fd, pour_point);

    % Compute runoff using SCS Curve Number method
    rainfall = 50; % mm
    CN = 75; % Curve Number
    runoff = scs_cn_runoff(rainfall, CN);

    % Compute watershed area
    cellsize = 30; % m
    area_m2 = sum(mask(:)) * cellsize^2;
    area_km2 = area_m2/1e6;

    % Estimate peak discharge using Rational method
    C = 0.5; % Runoff coefficient
    i = 30; % mm/h rainfall intensity
    Q_peak_m3s = rational_peak(C, i, area_km2);

    % Plot results
    figure('Name','Catchment Delineation','NumberTitle','off');
    subplot(2,3,1); imagesc(DEM); axis image; title('Original DEM'); colorbar
    subplot(2,3,2); imagesc(DEM_filled); axis image; title('Filled DEM'); colorbar
    subplot(2,3,3); imagesc(fd); axis image; title('Flow Direction (D8)'); colorbar
    subplot(2,3,4); imagesc(log10(fa+1)); axis image; title('Flow Accumulation (log10)'); colorbar
    subplot(2,3,5); imagesc(mask); axis image; title(sprintf('Watershed (%.3f km^2)', area_km2)); colorbar
    subplot(2,3,6);
    text(0.1,0.9,sprintf('Rainfall = %.1f mm\nCN = %d\nRunoff = %.2f mm\nPeak Q = %.2f m^3/s', rainfall, CN, runoff, Q_peak_m3s),'FontSize',12);
    axis off

    % Display results in command window
    fprintf('Area = %.3f km^2, Runoff = %.2f mm, Peak Q = %.2f m^3/s\n', area_km2, runoff, Q_peak_m3s);
end


% Supporting functions 


function DEM_filled = fill_sinks(DEM)
    % Fills depressions in DEM to ensure continuous flow
    DEM_filled = DEM;
    [rows,cols] = size(DEM);
    padDEM = padarray(DEM_filled, [1 1], Inf);
    changed = true; iter = 0;
    while changed && iter < 10000
        changed = false; iter = iter+1;
        for r = 2:rows+1
            for c = 2:cols+1
                neigh = padDEM(r-1:r+1,c-1:c+1);
                min_neigh = min(neigh(:));
                if padDEM(r,c) < min_neigh
                    padDEM(r,c) = min_neigh; changed = true;
                end
            end
        end
    end
    DEM_filled = padDEM(2:end-1,2:end-1);
end

function fd = flowdir_d8(DEM)
    % Computes flow direction for each cell using D8 algorithm
    [rows, cols] = size(DEM);
    fd = zeros(rows,cols);
    dR = [-1 -1 -1 0 0 1 1 1];
    dC = [-1 0 1 -1 1 -1 0 1];
    for r = 2:rows-1
        for c = 2:cols-1
            z = DEM(r,c);
            bestDrop = 0; bestIdx = 0;
            for k = 1:8
                nr = r + dR(k); nc = c + dC(k);
                dz = (z - DEM(nr,nc));
                dist = hypot(dR(k), dC(k));
                slope = dz/dist;
                if slope > bestDrop
                    bestDrop = slope; bestIdx = k;
                end
            end
            fd(r,c) = bestIdx;
        end
    end
    fd(1,:) = 0; fd(end,:) = 0; fd(:,1) = 0; fd(:,end) = 0;
end

function fa = flowacc_d8(fd)
    % Computes flow accumulation from D8 flow direction
    [rows,cols] = size(fd);
    fa = ones(rows,cols);
    dR = [-1 -1 -1 0 0 1 1 1];
    dC = [-1 0 1 -1 1 -1 0 1];
    indeg = zeros(rows,cols);
    for r=2:rows-1
        for c=2:cols-1
            dir = fd(r,c);
            if dir>0
                nr=r+dR(dir); nc=c+dC(dir);
                indeg(nr,nc) = indeg(nr,nc)+1;
            end
        end
    end
    Q = zeros(rows*cols,1); qh=1; qt=0;
    for r=1:rows
        for c=1:cols
            if indeg(r,c)==0
                qt=qt+1; Q(qt)=sub2ind([rows,cols],r,c);
            end
        end
    end
    while qh<=qt
        idx = Q(qh); qh=qh+1;
        [r,c] = ind2sub([rows,cols], idx);
        dir = fd(r,c);
        if dir>0
            nr=r+dR(dir); nc=c+dC(dir);
            fa(nr,nc) = fa(nr,nc) + fa(r,c);
            indeg(nr,nc) = indeg(nr,nc) - 1;
            if indeg(nr,nc)==0
                qt=qt+1; Q(qt)=sub2ind([rows,cols],nr,nc);
            end
        end
    end
end

function mask = delineate_from_pour(fd, pour_point)
    % Delineates all upstream cells draining to a given pour point
    [rows,cols] = size(fd);
    mask = false(rows,cols);
    target_idx = sub2ind([rows,cols], pour_point(2), pour_point(1));
    receivers = zeros(rows,cols);
    dR = [-1 -1 -1 0 0 1 1 1];
    dC = [-1 0 1 -1 1 -1 0 1];
    for r=1:rows
        for c=1:cols
            dir = fd(r,c);
            if dir>0
                nr = r + dR(dir); nc = c + dC(dir);
                if nr>=1 && nr<=rows && nc>=1 && nc<=cols
                    receivers(r,c) = sub2ind([rows,cols], nr, nc);
                else
                    receivers(r,c) = 0;
                end
            else
                receivers(r,c) = 0;
            end
        end
    end
    for r=1:rows
        for c=1:cols
            idx = sub2ind([rows,cols], r, c);
            path_idx = idx; visited = [];
            reached = false;
            while true
                if path_idx==0 || any(path_idx==visited)
                    break;
                end
                visited(end+1) = path_idx;
                if path_idx==target_idx
                    reached = true; break;
                end
                path_idx = receivers(path_idx);
            end
            if reached
                mask(r,c)=true;
            end
        end
    end
end

function runoff = scs_cn_runoff(P, CN)
    % Computes runoff depth using SCS Curve Number method
    S = (25400./CN - 254);
    Ia = 0.2 * S;
    if P <= Ia
        runoff = 0;
    else
        runoff = ((P - Ia).^2) ./ (P - Ia + S);
    end
end

function Q_peak = rational_peak(C, i_mm_per_hr, A_km2)
    % Estimates peak discharge using Rational method
    Q_peak = C .* i_mm_per_hr .* A_km2 .* (1000/3600);
end
