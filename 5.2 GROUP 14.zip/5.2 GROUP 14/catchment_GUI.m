function catchment_GUI
    % Create GUI figure
    fig = uifigure('Name','Catchment Delineation Tool','Position',[100 100 800 600]);

    % Axes to display DEM
    ax1 = uiaxes(fig,'Position',[50 300 700 250]);
    title(ax1,'Digital Elevation Model');

    % Button to load DEM
    btnLoad = uibutton(fig,'push','Text','Load DEM','Position',[50 200 100 30],...
        'ButtonPushedFcn', @(btn,event) loadDEM(ax1));

    % Button to delineate catchment
    btnDelineate = uibutton(fig,'push','Text','Delineate Catchment','Position',[200 200 150 30],...
        'ButtonPushedFcn', @(btn,event) delineateCatchment(ax1));

    % Button to simulate runoff
    btnRunoff = uibutton(fig,'push','Text','Simulate Runoff','Position',[400 200 150 30],...
        'ButtonPushedFcn', @(btn,event) simulateRunoff());

end

%% Callback Functions
function loadDEM(ax)
    [file,path] = uigetfile('*.tif','Select DEM File');
    if isequal(file,0)
        return;
    end
    [DEM,R] = readgeoraster(fullfile(path,file));
    DEM = double(DEM);
    axes(ax);
    imagesc(DEM);
    colormap(ax,'terrain');
    colorbar(ax);
    title(ax,'Digital Elevation Model');
    assignin('base','DEM',DEM);
    assignin('base','R',R);
end

function delineateCatchment(ax)
    DEM = evalin('base','DEM');
    % For simplicity, pick center as outlet
    outletRow = round(size(DEM,1)/2);
    outletCol = round(size(DEM,2)/2);

    FD = flowdirection(DEM,'D8');
    catchmentMask = watershed(FD, outletRow, outletCol);

    axes(ax);
    imagesc(catchmentMask);
    colormap(ax,'summer');
    colorbar(ax);
    title(ax,'Delineated Catchment');
end

function simulateRunoff()
    prompt = {'Enter rainfall (mm):','Enter Curve Number (CN):'};
    dlgtitle = 'Runoff Simulation';
    dims = [1 35];
    definput = {'50','75'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);

    rainfall = str2double(answer{1});
    CN = str2double(answer{2});
    S = 25400 / CN - 254;
    Ia = 0.2 * S;
    Q = ((rainfall - Ia)^2) / (rainfall - Ia + S);
    msgbox(['Estimated runoff (mm): ', num2str(Q)],'Runoff Result');
end
